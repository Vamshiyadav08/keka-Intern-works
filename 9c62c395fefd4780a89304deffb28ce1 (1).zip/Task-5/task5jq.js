$(document).ready(function () {
  $("input[type=radio]").on("input", function () {
    ele = this;
    setTimeout(function () {
      if ($(ele).val() == "male") alert("Hello sir");
      else alert("Hello Lady");
    });
  });

  $("#form").submit((event) => {
    event.preventDefault();
    submitForm();
  });

  let requiredFields = ["name", "email", "organisation"];
  function submitForm() {
    let errFlag = true;
    requiredFields.forEach((ele) => {
      if ($("#" + ele).val() == "") {
        $("#" + ele)
          .next()
          .text(ele + " is required");
        errFlag = false;
      } else
        $("#" + ele)
          .next()
          .text("*");
    });

    if ($("#email").val() != "") {
      let email = $("#email").val();
      let checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

      if (!email.match(checkmail)) {
        $("#email")
          .next()
          .text(email + " is invalid");
        errFlag = false;
      } else $("#email").next().text("*");
    }

    if (!errFlag)
      $("#requiredFeild").text("Please fill all the required feilds below");
    else {
      $("#requiredFeild").text("");
      alert("success");
    }
  }
  $("input[type=reset]").click(function () {
    let formm = $("#form");
    formm[0].reset();
    $("#myName").text("*");
    $("#myEmail").text("*");
    $("#myOrganisation").text("*");
    $("#requiredFeild").text("");
  });
  let stateArr = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu and Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttarakhand",
    "Uttar Pradesh",
    "West Bengal",
    "Andaman and Nicobar Islands",
    "Chandigarh",
    "Dadra and Nagar Haveli",
    "Daman and Diu",
    "Delhi",
    "Lakshadweep",
    "Puducherry",
  ];
  for (let i = 0; i < stateArr.length; i++) {
    var svalue = stateArr[i];
    const options = $("<option>").val(svalue).text(svalue);
    $("#state").append(options);
  }
  $("#state").click(function () {
    $("#promoCode").val($("#state").val() + "-PROMO");
  });
  $("#browsefile").click(function () {
    $("#getfile").click();
  });
  $("#getfile").change(function () {
    let filename = $("#getfile").val().split("\\").pop();
    $("#resume").val(filename);
  });
});
