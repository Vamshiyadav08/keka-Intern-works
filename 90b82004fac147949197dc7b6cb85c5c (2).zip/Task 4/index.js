var namerror = document.getElementById("name");
var emailerror = document.getElementById("email");
var orgerror = document.getElementById("Organisation");

var myName = document.getElementById("myName");
var myEmail = document.getElementById("myEmail");
var myOrganisation = document.getElementById("myOrganisation");
var reqfeild = document.getElementById("requiredFeild");
let checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

let arr = document.getElementsByName("my_gender");
for (let i = 0; i < arr.length; i++) {
  arr[i].addEventListener?.("change", alertMessage);
}
let form = document.getElementById("form");
form?.addEventListener('submit',function (event) {
  event.preventDefault();
  validation();
});
form.onreset=function(){
  form.reset();
  myName.textContent = "*";
  myEmail.textContent = "*";
  myOrganisation.textContent = "*";
  requiredFeild.textContent = "";
}

document.getElementById("state")?.addEventListener("change", selectionList);
document.getElementById("browsefile")?.addEventListener("click", filebrowse);
document.getElementById("getfile")?.addEventListener("input", filename);

function submitForm(checkValue, errorValue, content) {
  if (checkValue.value == "") {
    errorValue.textContent = `${content} is required`;
  } else if (checkValue == emailerror && !emailerror.value.match(checkmail)) {
    myEmail.textContent = `${emailerror.value} is inavalid`;
  } else {
    errorValue.textContent = "*";
  }
}

function validation() {
  submitForm(namerror, myName, "Name");
  submitForm(emailerror, myEmail, "Email");
  submitForm(orgerror, myOrganisation, "Organisation");

  if (namerror.value == "" || emailerror.value == "" || orgerror.value == "") {
    reqfeild.textContent = "Please fill all the required feilds below";
  }
  if (
    namerror.value !== "" &&
    emailerror.value !== "" &&
    orgerror.value !== "" &&
    emailerror.value.match(checkmail)
  ) {
    myName.textContent = "*";
    myEmail.textContent = "*";
    myOrganisation.textContent = "*";
    requiredFeild.textContent = "";
    reqfeild.textContent = "";
    setTimeout(function () {
      alert("Form is submitted");
    }, 100);
  }
}
function alertMessage() {
  let isMale = document.getElementById("male").checked;
  if (isMale) {
    setTimeout(function () {
      alert("Hello Sir...");
    }, 100);
  } else {
    setTimeout(function () {
      alert("Hello Lady...");
    }, 100);
  }
}

function selectionList() {
  let ele = document.getElementById("promoCode");
  let state = document.getElementById("state");
  ele.value = state.value + "-PROMO";
}
function filebrowse() {
  document.getElementById("getfile").click();
}
function filename() {
  let filename = document.getElementById("getfile").files[0].name;
  document.getElementById("resume").value = filename;
}
let stateArr = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jammu and Kashmir",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttarakhand",
  "Uttar Pradesh",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli",
  "Daman and Diu",
  "Delhi",
  "Lakshadweep",
  "Puducherry",
];
for (i = 0; i < stateArr.length; i++) {
  var stateELe = stateArr[i];
  const options = document.createElement("option");
  options.textContent = stateELe;
  options.setAttribute("value", stateELe);
  document.getElementById("state")?.appendChild(options);
}
