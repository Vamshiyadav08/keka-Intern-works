export class user{
    name:string;
    score:number;
    email:string;
    constructor(name:string,score:number,email:string){
        this.name=name;
        this.score=score;
        this.email=email
    }
}