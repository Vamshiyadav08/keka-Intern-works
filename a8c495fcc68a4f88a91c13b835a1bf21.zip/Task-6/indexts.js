import { user } from "./userModel.js";
let arr = [];
let checkEle;
let maincheckBox;
fetch("./user.json")
    .then((response) => response.json())
    .then((data) => showInfo(data));
function showInfo(data) {
    data.forEach((element) => {
        arr.push(new user(element.name, element.score, element.email));
    });
    renderTable();
    maincheckBox = document.querySelector("#maincheckbox");
    maincheckBox === null || maincheckBox === void 0 ? void 0 : maincheckBox.addEventListener("click", markAll);
    checkEle = document.getElementsByClassName("checkBox");
    for (let i = 0; i < checkEle.length; i++) {
        checkEle[i].addEventListener("click", function () {
            checkBox(checkEle[i]);
        });
    }
}
function renderTable() {
    let gridContainer = document.getElementById("gridContainer");
    for (let i = 0; i < arr.length; i++) {
        let checkBox = `<div class="input-feild">
    <span>
      <input type="checkbox" class="checkBox checkfeild"/>
    </span> </div>`;
        let name = `<div class="input-feild"><p class="items">${arr[i].name}</p></div>`;
        let score = `<div class="input-feild"><p class=" score items">${arr[i].score}</p></div>`;
        let email = `<div class="input-feild"><p class="items">${arr[i].email}</p></div>`;
        let blankCell = `<div class="input-feild"></div>`;
        gridContainer.innerHTML += checkBox;
        gridContainer.innerHTML += name;
        gridContainer.innerHTML += score;
        gridContainer.innerHTML += email;
        gridContainer.innerHTML += blankCell;
    }
}
let scoreEle = document.getElementsByClassName("score");
let btnEle = document.getElementById("clickBtn");
btnEle.addEventListener("click", calculate);
function checkBox(ele) {
    if (!ele.checked) {
        maincheckBox.checked = false;
        return;
    }
    else {
        for (let j = 0; j < checkEle.length; j++) {
            if (!checkEle[j].checked) {
                return;
            }
        }
        maincheckBox.checked = true;
    }
}
let searchEle = document.getElementById("searchBar");
searchEle.addEventListener("input", searchText);
function searchText() {
    let content = document.getElementsByClassName("items");
    for (let i = 0; i < content.length; i++) {
        let regex = new RegExp(searchEle.value + "(?!([^<]+)?<)", "gi");
        content[i].innerHTML = content[i].innerText.replace(regex, "<mark>$&</mark>");
    }
}
function calculate() {
    let avgEle = document.getElementById("average");
    let maxEle = document.getElementById("max");
    let totalSum = 0;
    let maxValue = 0;
    let count = 0;
    for (let i = 0; i < arr.length; i++) {
        let scoreValue = parseInt(scoreEle[i].innerText);
        if (checkEle[i].checked == true) {
            totalSum = totalSum + scoreValue;
            count = count + 1;
            if (maxValue < scoreValue) {
                maxValue = scoreValue;
            }
        }
    }
    maxEle.textContent = String(maxValue);
    if (totalSum == 0) {
        avgEle.textContent = String(count);
    }
    else {
        avgEle.textContent = String(Math.round(totalSum / count));
    }
}
function markAll() {
    for (let i = 0; i < checkEle.length; i++) {
        if (maincheckBox.checked) {
            checkEle[i].checked = true;
        }
        else {
            checkEle[i].checked = false;
        }
    }
}
