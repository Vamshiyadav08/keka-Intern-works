export class user{
   groupName :string;
    id:string;
    dateStamp :string;
    constructor(groupName:string,id:string,dateStamp:string){
        this.groupName=groupName,
        this.id = id,
        this.dateStamp=dateStamp;
    }
}