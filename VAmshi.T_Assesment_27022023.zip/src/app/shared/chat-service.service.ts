import { Injectable } from '@angular/core';
import { user } from './userModel';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ChatServiceService {

  constructor(private http:HttpClient) { }

  contactArray=new BehaviorSubject<user[]>([])

  private apiUrl ='https://63faf84a4e024687bf6fea0b.mockapi.io/user'
 getChat(){
  return this.http.get<user[]>(this.apiUrl);
 } 
 
 updateSubject(data:user[]){
  this.contactArray.next(data);
}

 postChat(chatObj:user){
   console.log(chatObj)
  return this.http.post<[]>(this.apiUrl,chatObj);
 }
 getChatList(id:string){
  const url = `${this.apiUrl}/${id}`
  console.log(url)
  return this.http.get<user>(url) 
}
getChatProfile(id:string){
  const url = `${this.apiUrl}/${id}`
  return this.http.get<user>(url)
  
}


}
