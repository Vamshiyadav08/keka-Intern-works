import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { user } from '../shared/userModel';
import {  Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ChatServiceService } from '../shared/chat-service.service';

@Component({
  selector: 'app-chats',
  templateUrl: './chats.component.html',
  styleUrls: ['./chats.component.css']
  
})
export class ChatsComponent implements OnInit  {
  userId!: string;
  chatUser: user = {
    groupName :'',
    id :'',
    dateStamp:''
  };

  anonymousImg="fa-solid fa-user-secret";
  userInput="";

  constructor(private router:Router,
    private activatedRoute:ActivatedRoute,
    private chatService:ChatServiceService){}

  ngOnInit(): void {
   
    this.activatedRoute.params.subscribe((params) => {
      this.userId = params['id'];
      this.chatService
      .getChatProfile(this.userId)
      .subscribe((data) => (this.chatUser = data));
      console.log(this.chatUser)
    });
  }    
}
