import { group } from '@angular/animations';
import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { ChatServiceService } from '../shared/chat-service.service';
import { user } from '../shared/userModel';
@Component({
  selector: 'app-chat-list',
  templateUrl: './chat-list.component.html',
  styleUrls: ['./chat-list.component.css']
})
export class ChatListComponent  {
  groupName!: string ;

  chatData:user []=[]

  constructor(private chatService:ChatServiceService){}

  groupIcon ='fa-solid fa-users'
  

  name: string | null = null;

  ngOnInit(): void {
    this.chatService.getChat().subscribe((data)=>this.chatData=data)
    this.chatService.contactArray.subscribe(data => this.chatData = data)
    
  }

 
}
