import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChatListComponent } from './chat-list/chat-list.component';
import { ChatPageComponent } from './chat-page/chat-page.component';
import { ChatsComponent } from './chats/chats.component';


const routes: Routes = [
  
  {
    path: 'chats', component:ChatPageComponent,
    children:[
      {
        path:"chatlist/:id", component:ChatsComponent
      },
    ]
  },
  { path: '', redirectTo: '/chats', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
