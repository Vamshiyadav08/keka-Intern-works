import { Component } from '@angular/core';
import { ChatServiceService } from '../shared/chat-service.service';
import { user } from '../shared/userModel';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-group',
  templateUrl: './add-group.component.html',
  styleUrls: ['./add-group.component.css']
})
export class AddGroupComponent {
  groupName!: string ;

  chatData:user []=[]

  constructor(private chatService:ChatServiceService){}

  addIcon = "fa-solid fa-plus"
  searchIcon ="fa-solid fa-magnifying-glass"
  groupIcon ='fa-solid fa-users'
  

  name: string | null = null;

  ngOnInit(): void {
    this.chatService.getChat().subscribe((data)=>this.chatData=data)
    this.chatService.contactArray.subscribe(data => this.chatData = data)
    
  }
  groupObj :user = {
    groupName :'',
    id :'',
    dateStamp:''
  };
  todayDate : string = new Date().toDateString();

  getData(){
    
     this.name = window.prompt('Please enter some data:');
     this.groupObj = new user(this.name!,'',this.todayDate)
     this.chatService.postChat(this.groupObj).subscribe(  )
  }
}
