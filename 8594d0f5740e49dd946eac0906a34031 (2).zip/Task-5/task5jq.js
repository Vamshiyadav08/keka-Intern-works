$(document).ready(function () {
  $("input[name='my_gender']").change(alertMessage);
  $("#form").submit(function (event) {
    event.preventDefault();
    submitForm();
  });
  $("input[type='reset']").click(clearForm);
  selectionList();
  $("#browsefile").click(filesubmission);
  $("#getfile").change(customfile);
});

function alertMessage() {
  setTimeout(() => {
    alert(`Hello ${this.value}..`);
  });
}
let checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
function validation(checkValue, errorValue, content) {
  let emailele = $("#email").val();

  if ($(checkValue).val() == "") {
    $(errorValue).text(`${content} is required`);
  } else if (checkValue == "#email" && !emailele.match(checkmail)) {
    $(errorValue).text(`${emailele} is invalid`);
  } else {
    $(errorValue).text("*");
  }
}
function submitForm() {
  validation("#name", "#myname", "Name");
  validation("#email", "#myemail", "Email");
  validation("#organisation", "#myorganisation", "Organisation");
  if (
    $("#name").val() != "" &&
    $("#email").val() != "" &&
    $("#organisation").val() != "" &&
    $("#email").val().match(checkmail)
  ) {
    setTimeout(function () {
      alert("submitted");
    });
    $("#requiredFeild").hide();
  } else {
    $("#requiredFeild").show();
    $("#requiredFeild").text("Please fill all the required feilds");
  }
}

function clearForm() {
  $("#myname").text("*");
  $("#myemail").text("*");
  $("#myorganisation").text("*");
  $("#requiredFeild").hide();
}
function selectionList() {
  let stateArr = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu and Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttarakhand",
    "Uttar Pradesh",
    "West Bengal",
    "Andaman and Nicobar Islands",
    "Chandigarh",
    "Dadra and Nagar Haveli",
    "Daman and Diu",
    "Delhi",
    "Lakshadweep",
    "Puducherry",
  ];
  for (let i = 0; i < stateArr.length; i++) {
    var svalue = stateArr[i];
    const options = $("<option>").val(svalue).text(svalue);
    console.log(options);
    $("#state").append(options);
  }
  $("#state").change(function () {
    $("#promoCode").val($("#state").val() + "-PROMO");
  });
}
function filesubmission() {
  $("#getfile").click();
}
function customfile() {
  let filename = $("#getfile").val().split("\\").pop();
  $("#resume").val(filename);
}
