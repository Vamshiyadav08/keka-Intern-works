import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VeiwAlldetailsComponent } from './veiw-alldetails.component';

describe('VeiwAlldetailsComponent', () => {
  let component: VeiwAlldetailsComponent;
  let fixture: ComponentFixture<VeiwAlldetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VeiwAlldetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VeiwAlldetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
