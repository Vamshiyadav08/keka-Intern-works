import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FormContainerComponent } from './form-container/form-container.component';
import { AsidehoverSectionComponent } from './asidehover-section/asidehover-section.component';
import { VeiwAlldetailsComponent } from './veiw-alldetails/veiw-alldetails.component';
import { ReactiveFormsModule } from '@angular/forms';

import { UserdetailsService } from './userdetails.service';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddComponent } from './add/add.component';

const appRoute : Routes =[
  {
    path:'', component:HomeComponent
  },
  {
    path:'add',component: AddComponent},
  
  {
    path:'veiwallDetails/:id', component: VeiwAlldetailsComponent
  },
  {
    path:'edit', component:FormContainerComponent
  }
  
]
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FormContainerComponent,
    AsidehoverSectionComponent,
    VeiwAlldetailsComponent,
    HomeComponent,
    AddComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoute)
  ],
  providers: [UserdetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
