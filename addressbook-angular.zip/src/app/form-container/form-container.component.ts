import {
  Component,
  ElementRef,
  ViewChild,
  OnInit
  
} from '@angular/core';

import { FormControl, FormGroup, Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { UserdetailsService } from '../userdetails.service';
import { ActivatedRoute } from '@angular/router';

import { user } from './user';

@Component({
  selector: 'app-form-container',
  templateUrl: './form-container.component.html',
  styleUrls: ['./form-container.component.css'],
})
export class FormContainerComponent {
  constructor(
    private serviceDb: UserdetailsService,
    private router: Router,   
    private route: ActivatedRoute
  ) {}

  display:boolean = false
  idddd:number=-1;
  
  myForm = new FormGroup({
    nameEle: new FormControl('',[Validators.required]),
    email: new FormControl('',[Validators.required,Validators.email]),
    mobile: new FormControl('',[Validators.required]),
    landline: new FormControl(''),
    website: new FormControl(''),
    address: new FormControl(''),
  });
  currentUser: user = {nameEle: '',email: '',mobile: '',landline: '',website: '',address: '',_id: -1,};
  autofill(userid: number) {
    for (let each of this.serviceDb.userArray) {
      if (each._id == userid) {
        this.myForm.patchValue({
          nameEle: each.nameEle,
          email:each.email,
          mobile:each.mobile,
          landline:each.landline,
          website : each.website,
          address : each.address
        })
        break;
      }
    }  
  }
  ngOnInit(): void {
    this.route.queryParamMap.subscribe((qparams) => {
      let userid = +qparams.get('id')!;
      if(userid != undefined){
        this.idddd = userid
      }
      let isdisplay = qparams.get('display');
      if (isdisplay) {
        this.display = true
        this.autofill(userid);
      }
    });
  }
  onSubmit() {
    let newob: user = {
      _id : (Math.random()*100000),
      nameEle : (this.myForm.value.nameEle)!,
      email :(this.myForm.value.email)!,
      mobile : (this.myForm.value.mobile)!,
      landline : (this.myForm.value.landline)!,
      address : (this.myForm.value.address)!,
      website : (this.myForm.value.website)!
    };  
      if (this.display) {
        let newList = this.serviceDb.userArray;
        console.log(newList.length)
         for(let i=0 ; i<newList.length;i++){
           if(newList[i]._id==this.idddd){
            let  newobj :user ={
               _id :this.serviceDb.userArray[i]._id,
               nameEle :( this.myForm.value.nameEle)!,
               email :(this.myForm.value.email)!,
                mobile : (this.myForm.value.mobile)!,
                landline : (this.myForm.value.landline)!,
                address : (this.myForm.value.address)!,
                website : (this.myForm.value.website)!
             }
             this.serviceDb.userArray.splice(i,1,newobj) 
           }
           
          }  
      }else{
        this.serviceDb.userArray.push(newob);
      }
    this.router.navigate(['']);
  }

}
