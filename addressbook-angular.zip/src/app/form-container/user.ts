export class user {
  _id: number;
  nameEle: string;
  email: string;
  mobile: string;
  landline: string;
  website: string;
  address: string;

  constructor(
    nameEle: string,
    email: string,
    mobile: string,
    landline: string,
    website: string,
    address: string,
    _id: number
  ) {
    (this._id = _id),
      (this.nameEle = nameEle),
      (this.email = email),
      (this.mobile = mobile),
      (this.landline = landline),
      (this.website = website),
      (this.address = address);
  }
}
