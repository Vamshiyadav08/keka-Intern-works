import { Injectable } from '@angular/core';

import { user } from './form-container/user';

@Injectable({
  providedIn: 'root'
})
export class UserdetailsService {

  constructor() { }

  userArray :Array<user> =[
    
  ]


}
