var namerror =document.getElementById('name');
var emailerror =document.getElementById('email');
var orgerror =document.getElementById('Organisation');

var myName = document.getElementById('myName');
var myEmail = document.getElementById('myEmail');
var myOrganisation =document.getElementById('myOrganisation');
var reqfeild =document.getElementById('requiredFeild');
let checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

function validation(){
    console.log(namerror)
   
     if (namerror.value==""){
         myName.textContent=" Name is required";
         
     }
     else{
         myName.textContent="*";
     }
     
     
    
    
    if(emailerror.value==""){
        myEmail.textContent=" Email is required";
    }
    else if(! emailerror.value.match(checkmail)){
        myEmail.textContent=`${emailerror.value} is inavalid`;
    }else{
        myEmail.textContent=" * ";
    }

     if(orgerror.value==""){
         myOrganisation.textContent=" Organisation is required";
     }
     else{
        myOrganisation.textContent="*";
     }
    
     if(namerror.value=="" ||  emailerror.value=="" || orgerror.value==""){
        reqfeild.textContent = "Please fill all the required feilds below";
        
     }
     if(namerror.value!=="" &&  emailerror.value!=="" && orgerror.value!==""){
        alert("Submitted");
        reqfeild.textContent = " * ";
        
        
     }
    
}
function remove(){
    
    let formm = document.getElementById('formId');
    formm.reset();
    myName.textContent="*";
    myEmail.textContent="*";
    myOrganisation.textContent="*";
    requiredFeild.textContent="";
    
}
function alertMale(){
    alert("Hello Sir")
} 
function alertFemale(){
    alert("Hello Lady")
}
function selection(){
    let ele = document.getElementById("promoCode");
    let state = document.getElementById("state")
    ele.value= state.value + "-PROMO";

}
