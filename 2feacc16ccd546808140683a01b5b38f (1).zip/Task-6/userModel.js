export class user {
    constructor(name, score, email) {
        this.name = name;
        this.score = score;
        this.email = email;
    }
}
