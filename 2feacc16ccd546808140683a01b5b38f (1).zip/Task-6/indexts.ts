import { user } from "./userModel.js";
let arr: user[] = [];
let checkEle: HTMLCollectionOf<HTMLInputElement>;
let maincheckBox: HTMLInputElement;

const fetchUserdata = async () => {
  const response = await fetch("./user.json");
  const data = await response.json();
  initialization(data);
};
fetchUserdata();

function initialization(data: user[]) {
  data.forEach((element: user) => {
    arr.push(new user(element.name, element.score, element.email));
  });
  renderTable();
  maincheckBox = document.querySelector("#maincheckbox")!;
  maincheckBox.addEventListener("click", selectAll);
  checkEle = document.getElementsByClassName("checkBox") as HTMLCollectionOf<HTMLInputElement>;
  for (let i = 0; i < checkEle.length; i++) {
    checkEle[i].addEventListener("click", function () {
      checkEachBox(checkEle[i]);
    });
  }
}
function renderTable() {
  let gridContainer = document.getElementById("gridContainer") as HTMLElement;
  for (let i = 0; i < arr.length; i++) {
    let checkBox = `<div class="input-feild">
    <span>
      <input type="checkbox" class="checkBox checkfeild"/>
    </span> </div>`;
    let name = `<div class="input-feild"><p class="items">${arr[i].name}</p></div>`;
    let score = `<div class="input-feild"><p class=" score items">${arr[i].score}</p></div>`;
    let email = `<div class="input-feild"><p class="items">${arr[i].email}</p></div>`;
    let blankCell = `<div class="input-feild"></div>`;
    gridContainer.innerHTML += checkBox;
    gridContainer.innerHTML += name;
    gridContainer.innerHTML += score;
    gridContainer.innerHTML += email;
    gridContainer.innerHTML += blankCell;
  }
}
let btnEle = document.getElementById("clickBtn") as HTMLElement;
btnEle.addEventListener("click", calculateScore);

let searchEle = document.getElementById("searchBar") as HTMLInputElement;
searchEle.addEventListener("input", searchText);

function checkEachBox(ele: HTMLInputElement) {
  if (!ele.checked) {
    maincheckBox.checked = false;
    return;
  } else {
    for (let j = 0; j < checkEle.length; j++) {
      if (!checkEle[j].checked) {
        return;
      }
    }
    maincheckBox.checked = true;
  }
}

function searchText() {
  let content = document.getElementsByClassName("items") as HTMLCollectionOf<HTMLElement>;
  for (let i = 0; i < content.length; i++) {
    let searchKey = searchEle.value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    let regex = new RegExp(searchKey, "gi");
    content[i].innerHTML = content[i].innerText.replace(regex,"<mark>$&</mark>");
  }
}
let avgEle = document.getElementById("average") as HTMLElement;
let maxEle = document.getElementById("max") as HTMLElement;

function calculateScore() {
  let checkBoxArr = Array.from(checkEle);
  let scores: number[] = [];
  checkBoxArr.forEach((ele, index) => {
    if (ele.checked) {
      scores.push(arr[index].score);
    }
  });
  calculateAverage(scores);
  calculateMaximum(scores);
}
function calculateAverage(scores: number[]) {
  let totalSum: number = 0;
  if (scores.length != 0) {
    totalSum = scores.reduce((total, ele) => {
      return (total += ele);
    });
  }
  let avgerage = ((totalSum > 0) as boolean)? Math.round(totalSum / scores.length): 0;
  avgEle.textContent = String(avgerage);
}

function calculateMaximum(scores: number[]) {
  let maximumValue = ((scores.length > 0) as boolean) ? Math.max(...scores) : 0;
  maxEle.textContent = String(maximumValue);
}

function selectAll() {
  for (let i = 0; i < checkEle.length; i++) {
    let checkedValue = ((maincheckBox.checked) as boolean)?true:false;
    checkEle[i].checked = checkedValue;
  }
}
