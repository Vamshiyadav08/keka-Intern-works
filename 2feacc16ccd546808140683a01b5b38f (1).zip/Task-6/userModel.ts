export class user{
    name:string;
    score:number;
    email:string;
  checked: unknown;
    constructor(name:string,score:number,email:string){
        this.name=name;
        this.score=score;
        this.email=email
    }
}