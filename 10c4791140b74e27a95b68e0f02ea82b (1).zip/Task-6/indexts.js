var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { user } from "./userModel.js";
let arr = [];
let checkEle;
let maincheckBox;
const fetchUserdata = () => __awaiter(void 0, void 0, void 0, function* () {
    const response = yield fetch("./user.json");
    const data = yield response.json();
    initialization(data);
});
fetchUserdata();
function initialization(data) {
    data.forEach((element) => {
        arr.push(new user(element.name, element.score, element.email));
    });
    renderTable();
    maincheckBox = document.querySelector("#maincheckbox");
    maincheckBox.addEventListener("click", selectAll);
    checkEle = document.getElementsByClassName("checkBox");
    for (let i = 0; i < checkEle.length; i++) {
        checkEle[i].addEventListener("click", function () {
            checkEachBox(checkEle[i]);
        });
    }
}
function renderTable() {
    let gridContainer = document.getElementById("gridContainer");
    for (let i = 0; i < arr.length; i++) {
        let rowContainer = `<div class="row-container">
    <div class="input-feild">
      <span>
        <input type="checkbox" class="checkBox checkfeild"/>
      </span> 
    </div>
    <div class="input-feild"><p class="items">${arr[i].name}</p></div>
    <div class="input-feild"><p class=" score items">${arr[i].score}</p></div>
    <div class="input-feild"><p class="items">${arr[i].email}</p></div>
    <div class="input-feild"></div>
    </div>`;
        gridContainer.innerHTML += rowContainer;
    }
}
let btnEle = document.getElementById("clickBtn");
btnEle.addEventListener("click", calculateScore);
let searchEle = document.getElementById("searchBar");
searchEle.addEventListener("input", searchText);
function checkEachBox(ele) {
    if (!ele.checked) {
        maincheckBox.checked = false;
        return;
    }
    else {
        for (let j = 0; j < checkEle.length; j++) {
            if (!checkEle[j].checked) {
                return;
            }
        }
        maincheckBox.checked = true;
    }
}
function searchText() {
    let content = document.getElementsByClassName("items");
    for (let i = 0; i < content.length; i++) {
        let searchKey = searchEle.value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        let regex = new RegExp(searchKey, "gi");
        content[i].innerHTML = content[i].innerText.replace(regex, "<mark>$&</mark>");
    }
}
let avgEle = document.getElementById("average");
let maxEle = document.getElementById("max");
function calculateScore() {
    let checkBoxArr = Array.from(checkEle);
    let scores = [];
    checkBoxArr.forEach((ele, index) => {
        if (ele.checked) {
            scores.push(arr[index].score);
        }
    });
    calculateAverage(scores);
    calculateMaximum(scores);
}
function calculateAverage(scores) {
    let totalSum = 0;
    if (scores.length != 0) {
        totalSum = scores.reduce((total, ele) => {
            return (total += ele);
        });
    }
    let avgerage = (totalSum > 0) ? Math.round(totalSum / scores.length) : 0;
    avgEle.textContent = String(avgerage);
}
function calculateMaximum(scores) {
    let maximumValue = (scores.length > 0) ? Math.max(...scores) : 0;
    maxEle.textContent = String(maximumValue);
}
function selectAll() {
    for (let i = 0; i < checkEle.length; i++) {
        let checkedValue = (maincheckBox.checked) ? true : false;
        checkEle[i].checked = checkedValue;
    }
}
