interface formEle {
  _id: number;
  nameEle: string;
  email: string;
  mobile: string;
  landline: string;
  website: string;
  address: string;
}
let count = 0;
let nameEle = document.getElementById("name") as HTMLInputElement;
let email = document.getElementById("email") as HTMLInputElement;
let mobile = document.getElementById("mobile") as HTMLInputElement;
let landline = document.getElementById("landline") as HTMLInputElement;
let website = document.getElementById("website") as HTMLInputElement;
let address = document.getElementById("address") as HTMLInputElement;
let asideContainer = document.getElementById("asideContainer") as HTMLElement;
let editBtn = document.getElementById("editBtn") as HTMLElement;
let deleteBtn = document.getElementById("deleteBtn") as HTMLElement;
let requiredFeild = document.getElementById("requiredFeild") as HTMLInputElement;
let savechangesbtn = document.getElementById("saveChangesbtn") as HTMLButtonElement;
let formContainer = document.getElementById("form") as HTMLFormElement;

let nameError = document.getElementById("nameError") as HTMLElement;
let emailError =document.getElementById("eamilError") as HTMLElement;
let mobileError =document.getElementById("mobileError") as HTMLElement;

let arrDatabase: Array<object> = [];

let home = document.getElementById("Home")
home?.addEventListener("click",homeSection)


let showformbtn = document.getElementById("showForm") as HTMLElement;
showformbtn.addEventListener("click", showForm);

let addFormBtn = document.getElementById("addFormbtn") as HTMLElement;
let allDetailsContainer = document.getElementById("veiwdetails") as HTMLElement;


function homeSection(){
 asidehoverSection()
}

function showForm(){
  formContainer.classList.remove("hide-form");
  allDetailsContainer.classList.add("hide-details");
  addFormBtn.classList.remove("hide-details");
  addFormBtn.addEventListener("click", addForm);
  savechangesbtn.classList.add("hide-details")
}

function asidehoverSection(){
  formContainer.classList.add("hide-form");
  asideContainer.innerHTML = "";
  for (let i = 0; i < arrDatabase.length; i++) {
    let asideitem = `<div class="aside-section" id="section${(arrDatabase[i] as formEle)._id}">
                    <p class="aside-header">${(arrDatabase[i] as formEle).nameEle}</p>
                    <p class="aside-item">${(arrDatabase[i] as formEle).email}</p>
                    <p class="aside-item">${(arrDatabase[i] as formEle).mobile}</p> </div>`;

    let addlistSection = document.createElement("div");
    addlistSection.setAttribute("id", `${(arrDatabase[i] as formEle)._id}`);
    addlistSection.innerHTML = asideitem;

    addlistSection.onclick = function () {
      veiwAllDetails(arrDatabase[i] as formEle);
    };
    asideContainer.appendChild(addlistSection);
  }
}

function formValidation(checkfeild: HTMLInputElement,errorfeild: HTMLElement ,content: string){
  if(checkfeild.value==""){
    errorfeild.textContent=`*${content} is required`
    requiredFeild.textContent="*Please fill the required feilds"
  }
  else{
    errorfeild.textContent=""
  }
}

function addForm(){
 if(nameEle.value!="" && email.value!="" && mobile.value!=""){
  let obj: formEle = {
    _id: count,
    nameEle: nameEle.value,
    email: email.value,
    mobile: mobile.value,
    landline: landline.value,
    website: website.value,
    address: address.value,
  };
  count += 1;
  arrDatabase.push(obj);
  asidehoverSection();
  requiredFeild.textContent=""
  nameError.textContent=""
  emailError.textContent=""
  mobileError.textContent=""
  formContainer.reset();
 }
 else{
  formValidation(nameEle,nameError,"name");
  formValidation(email,emailError,"emil")
  formValidation(mobile,mobileError,"mobile")
 } 
}

function veiwAllDetails(obj: formEle) {
  formContainer.classList.add("hide-form");
  allDetailsContainer.classList.remove("hide-details");
  (<HTMLElement>document.getElementById("menuName")).textContent = obj.nameEle;
  (<HTMLElement>document.getElementById("menuEmail")).textContent = obj.email;
  (<HTMLElement>document.getElementById("menuMobile")).textContent = (obj.mobile);
  (<HTMLElement>document.getElementById("menuLandline")).textContent = (obj.landline);
  (<HTMLElement>document.getElementById("menuwebsite")).textContent = obj.website;
  (<HTMLElement>document.getElementById("menuAdress")).textContent = obj.address;

  editBtn.addEventListener("click", function () {
    editForm(obj);
  });
  deleteBtn.addEventListener("click", function () {
    deleteForm(obj);
  }); 
}

function editForm(obj: formEle) {
  formContainer.classList.remove("hide-form");
  allDetailsContainer.classList.add("hide-details");
  
  savechangesbtn.classList.remove("hide-details");
  addFormBtn.classList.add("hide-details");

  nameEle.value = obj.nameEle;
  mobile.value = obj.mobile;
  email.value = obj.email;
  landline.value = obj.landline;
  website.value = obj.website;
  address.value = obj.address;

  savechangesbtn.onclick = function () {
    for (let i = 0; i < arrDatabase.length; i++) {
      if ((arrDatabase[i] as formEle)._id === obj._id) {
          arrDatabase[i] = {
          _id: obj._id,
          nameEle: nameEle.value,
          mobile: mobile.value,
          email: email.value,
          landline: landline.value,
          website: website.value,
          address: address.value,
        };
        veiwAllDetails(arrDatabase[i] as formEle)
        break;
      }
    }
    formContainer.reset();
    asidehoverSection(); 
    formContainer.classList.add("hide-form");
  };
}

function deleteForm(obj: formEle) {
  let newarr: Array<object> = [];
  for (let i = 0; i < arrDatabase.length; i++) {
    if ((arrDatabase[i] as formEle)._id === obj._id) {
      continue
    }
    else{
      newarr.push(arrDatabase[i])
    }
  }
  arrDatabase = newarr
  asidehoverSection();
  allDetailsContainer.classList.add("hide-details")
}
