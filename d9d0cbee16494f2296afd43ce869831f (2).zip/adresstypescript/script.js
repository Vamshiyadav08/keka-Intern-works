"use strict";
let count = 0;
let nameEle = document.getElementById("name");
let email = document.getElementById("email");
let mobile = document.getElementById("mobile");
let landline = document.getElementById("landline");
let website = document.getElementById("website");
let address = document.getElementById("address");
let asideContainer = document.getElementById("asideContainer");
let editBtn = document.getElementById("editBtn");
let deleteBtn = document.getElementById("deleteBtn");
let requiredFeild = document.getElementById("requiredFeild");
let savechangesbtn = document.getElementById("saveChangesbtn");
let formContainer = document.getElementById("form");
let nameError = document.getElementById("nameError");
let emailError = document.getElementById("eamilError");
let mobileError = document.getElementById("mobileError");
let arrDatabase = [];
let home = document.getElementById("Home");
home?.addEventListener("click", homeSection);
let showformbtn = document.getElementById("showForm");
showformbtn.addEventListener("click", showForm);
let addFormBtn = document.getElementById("addFormbtn");
let allDetailsContainer = document.getElementById("veiwdetails");
function homeSection() {
    asidehoverSection();
}
function showForm() {
    formContainer.classList.remove("hide-form");
    allDetailsContainer.classList.add("hide-details");
    addFormBtn.classList.remove("hide-details");
    addFormBtn.addEventListener("click", addForm);
    savechangesbtn.classList.add("hide-details");
}
function asidehoverSection() {
    formContainer.classList.add("hide-form");
    asideContainer.innerHTML = "";
    for (let i = 0; i < arrDatabase.length; i++) {
        let asideitem = `<div class="aside-section" id="section${arrDatabase[i]._id}">
                    <p class="aside-header">${arrDatabase[i].nameEle}</p>
                    <p class="aside-item">${arrDatabase[i].email}</p>
                    <p class="aside-item">${arrDatabase[i].mobile}</p> </div>`;
        let addlistSection = document.createElement("div");
        addlistSection.setAttribute("id", `${arrDatabase[i]._id}`);
        addlistSection.innerHTML = asideitem;
        addlistSection.onclick = function () {
            veiwAllDetails(arrDatabase[i]);
        };
        asideContainer.appendChild(addlistSection);
    }
}
function formValidation(checkfeild, errorfeild, content) {
    if (checkfeild.value == "") {
        errorfeild.textContent = `*${content} is required`;
        requiredFeild.textContent = "*Please fill the required feilds";
    }
    else {
        errorfeild.textContent = "";
    }
}
function addForm() {
    if (nameEle.value != "" && email.value != "" && mobile.value != "") {
        let obj = {
            _id: count,
            nameEle: nameEle.value,
            email: email.value,
            mobile: mobile.value,
            landline: landline.value,
            website: website.value,
            address: address.value,
        };
        count += 1;
        arrDatabase.push(obj);
        asidehoverSection();
        requiredFeild.textContent = "";
        nameError.textContent = "";
        emailError.textContent = "";
        mobileError.textContent = "";
        formContainer.reset();
    }
    else {
        formValidation(nameEle, nameError, "name");
        formValidation(email, emailError, "emil");
        formValidation(mobile, mobileError, "mobile");
    }
}
function veiwAllDetails(obj) {
    formContainer.classList.add("hide-form");
    allDetailsContainer.classList.remove("hide-details");
    document.getElementById("menuName").textContent = obj.nameEle;
    document.getElementById("menuEmail").textContent = obj.email;
    document.getElementById("menuMobile").textContent = (obj.mobile);
    document.getElementById("menuLandline").textContent = (obj.landline);
    document.getElementById("menuwebsite").textContent = obj.website;
    document.getElementById("menuAdress").textContent = obj.address;
    editBtn.addEventListener("click", function () {
        editForm(obj);
    });
    deleteBtn.addEventListener("click", function () {
        deleteForm(obj);
    });
}
function editForm(obj) {
    formContainer.classList.remove("hide-form");
    allDetailsContainer.classList.add("hide-details");
    savechangesbtn.classList.remove("hide-details");
    addFormBtn.classList.add("hide-details");
    nameEle.value = obj.nameEle;
    mobile.value = obj.mobile;
    email.value = obj.email;
    landline.value = obj.landline;
    website.value = obj.website;
    address.value = obj.address;
    savechangesbtn.onclick = function () {
        for (let i = 0; i < arrDatabase.length; i++) {
            if (arrDatabase[i]._id === obj._id) {
                arrDatabase[i] = {
                    _id: obj._id,
                    nameEle: nameEle.value,
                    mobile: mobile.value,
                    email: email.value,
                    landline: landline.value,
                    website: website.value,
                    address: address.value,
                };
                veiwAllDetails(arrDatabase[i]);
                break;
            }
        }
        formContainer.reset();
        asidehoverSection();
        formContainer.classList.add("hide-form");
    };
}
function deleteForm(obj) {
    let newarr = [];
    for (let i = 0; i < arrDatabase.length; i++) {
        if (arrDatabase[i]._id === obj._id) {
            continue;
        }
        else {
            newarr.push(arrDatabase[i]);
        }
    }
    arrDatabase = newarr;
    asidehoverSection();
    allDetailsContainer.classList.add("hide-details");
}
