var namerror = document.getElementById("name");
var emailerror = document.getElementById("email");
var orgerror = document.getElementById("Organisation");

var myName = document.getElementById("myName");
var myEmail = document.getElementById("myEmail");
var myOrganisation = document.getElementById("myOrganisation");
var reqfeild = document.getElementById("requiredFeild");
let checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

document.getElementById("male")?.addEventListener("click", gender);
document.getElementById("female")?.addEventListener("click", gender);
document.getElementById("state")?.addEventListener("change", selection);
document.getElementById("send-button")?.addEventListener("click", validation);
document.getElementById("clear-button")?.addEventListener("click", remove);

document.getElementById("browsefile")?.addEventListener("click",filebrowse);
document.getElementById("getfile")?.addEventListener("input",filename);



function easy(namee, myname, x) {
  if (namee.value == "") {
    myname.textContent = `${x} is required`;
  } else if (namee == emailerror && !emailerror.value.match(checkmail)) {
    myEmail.textContent = `${emailerror.value} is inavalid`;
  } else {
    myname.textContent = "*";
  }
}

function validation() {
  easy(namerror, myName, "Name");
  easy(emailerror, myEmail, "Email");
  easy(orgerror, myOrganisation, "Organisation");

  if (namerror.value == "" || emailerror.value == "" || orgerror.value == "") {
    reqfeild.textContent = "Please fill all the required feilds below";
  }
  if (
    namerror.value !== "" &&
    emailerror.value !== "" &&
    orgerror.value !== "" &&
    emailerror.value.match(checkmail)
  ) {
    myName.textContent = "*";
    myEmail.textContent = "*";
    myOrganisation.textContent = "*";
    requiredFeild.textContent = "";
    reqfeild.textContent = "";
    setTimeout(function(){
      alert("Form is submitted")
    },100)
  }
}
function gender() {
  let isMale = document.getElementById("male").checked;
  if (isMale) {
    setTimeout(function(){
      alert("Hello Sir...");
    },100)
  } else {
    setTimeout(function(){
      alert("Hello Lady...");
    },100)
   
  }
}
function remove() {
  let formm = document.getElementById("formId");
  formm.reset();
  myName.textContent = "*";
  myEmail.textContent = "*";
  myOrganisation.textContent = "*";
  requiredFeild.textContent = "";
}
function selection() {
  let ele = document.getElementById("promoCode");
  let state = document.getElementById("state");
  ele.value = state.value + "-PROMO";
}
function filebrowse() {
  document.getElementById("getfile").click();
}
function filename() {
  let filename = document.getElementById("getfile").files[0].name;
  document.getElementById("resume").value = filename;
}
let stateArr = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jammu and Kashmir",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttarakhand",
  "Uttar Pradesh",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli",
  "Daman and Diu",
  "Delhi",
  "Lakshadweep",
  "Puducherry",
];
for(i=0;i<stateArr.length;i++){
    var svalue = stateArr[i];
    const options = document.createElement("option");
    options.textContent=svalue;
    options.setAttribute("value", svalue);
    document.getElementById("state").appendChild(options)

}

