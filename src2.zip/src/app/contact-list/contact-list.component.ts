import { Component, OnInit } from '@angular/core';

import { ContactService } from '../shared/contact.service';
import { user } from '../shared/userModel';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit{
  contactData: any=[]
 
  constructor(private contactService :ContactService){}
  ngOnInit(): void {
    this.contactService.getContacts().subscribe((data)=>this.contactService.updateSubject(data))
    this.contactService.contactArray.subscribe(data => this.contactData = data)

  }
 


}
