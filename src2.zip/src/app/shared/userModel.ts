
export class user{
    id:string;
    name:string;
    email:string;
    mobile:string;
    landline:string;
    website:string;
    address:string;
    constructor(id:string,name:string,email:string,mobile:string,landline:string,website:string,address:string){
        this.id= id,
        this.name=name,
        this.email=email,
        this.address=address,
        this.landline=landline,
        this.mobile=mobile,
        this.website=website
        
    }
}

// // function uuid(): string {
//     throw new Error('Function not implemented.');
// }
