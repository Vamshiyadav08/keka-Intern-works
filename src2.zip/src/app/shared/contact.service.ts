import { Injectable } from '@angular/core';
import { user } from './userModel';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class ContactService {
  sub: any;

  constructor(private http:HttpClient) {}


  contactArray=new BehaviorSubject<user[]>([]);
  private apiUrl = 'https://63faf84a4e024687bf6fea0b.mockapi.io/user';
  
  getContacts(){
    return this.http.get<user[]>(this.apiUrl)
  }

  updateSubject(data:user[]){
    this.contactArray.next(data);
  }

  postContact(contactObj : user){
    return this.http.post<[]>(this.apiUrl,contactObj);    
  }

  deleteContact(id:string){
    const url = `${this.apiUrl}/${id}`
    return this.http.delete(url)
   
  }
  
  editContact(id:string){
    const url = `${this.apiUrl}/${id}`
    console.log(url)
    return this.http.get<user>(url)
  }
  getContactProfile(id:string){
    const url = `${this.apiUrl}/${id}`
    console.log(url)

    return this.http.get<user>(url)
    
  }
  edit(user: user){
    console.log(user)
    console.log("editing ")
    return this.http.put<user>(this.apiUrl, user)
    

  }
}

