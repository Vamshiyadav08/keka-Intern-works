import { Injectable } from '@angular/core';

import { user } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserdetailsService {

  constructor() { }

  userArray :Array<user> =[]

  insertContact(newobj:user){
    this.userArray.push(newobj);
    // console.log(newobj)
  }

  editContact(index:number,userObject:user){
    this.userArray.splice(index,1,userObject) 
  }
  deleteContact(){

  }
 

}
