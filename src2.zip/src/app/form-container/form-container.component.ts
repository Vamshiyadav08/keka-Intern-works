import {
  Component, 
} from '@angular/core';

import { FormControl, FormGroup, Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { UserdetailsService } from '../shared/userdetails.service';
import { ActivatedRoute } from '@angular/router';
import { user } from '../shared/user';

@Component({
  selector: 'app-form-container',
  templateUrl: './form-container.component.html',
  styleUrls: ['./form-container.component.css'],
})
export class FormContainerComponent {
  constructor(
    private serviceDb: UserdetailsService,
    private router: Router,   
    private route: ActivatedRoute
  ) {}

  display:boolean = false
  id:number=-1;
  
  myForm = new FormGroup({
    name: new FormControl('',[Validators.required]),
    email: new FormControl('',[Validators.required,Validators.email]),
    mobile: new FormControl('',[Validators.required]),
    landline: new FormControl(''),
    website: new FormControl(''),
    address: new FormControl(''),
  });
  // currentUser: user = {name: '',email: '',mobile: '',landline: '',website: '',address: '',id: -1,};

  autofill(userid: number) {
    for (let each of this.serviceDb.userArray) {
      if (each.id == userid) {
        this.myForm.patchValue({
          name: each.name,
          email:each.email,
          mobile:each.mobile,
          landline:each.landline,
          website : each.website,
          address : each.address
        })
        break;
      }
    }  
  }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe((qparams) => {
      let userid = +qparams.get('id')!;
      if(userid != undefined){
        this.id = userid
      }
      let isdisplay = qparams.get('display');
      if (isdisplay) {
        this.display = true
        this.autofill(userid);
      }
    });
  }
  onSubmit() {
    console.log(this.myForm)
    let newob: user = {
      id : (Math.random()*100000000000000),
      name : (this.myForm.value.name)!,
      email :(this.myForm.value.email)!,
      mobile : (this.myForm.value.mobile)!,
      landline : (this.myForm.value.landline)!,
      address : (this.myForm.value.address)!,
      website : (this.myForm.value.website)!
    };  
      if (this.display) {
        let newList = this.serviceDb.userArray;
        console.log(newList.length)
         for(let i=0 ; i<newList.length;i++){
           if(newList[i].id==this.id){
            let  newobj :user ={
               id :this.serviceDb.userArray[i].id,
               name :( this.myForm.value.name)!,
               email :(this.myForm.value.email)!,
                mobile : (this.myForm.value.mobile)!,
                landline : (this.myForm.value.landline)!,
                address : (this.myForm.value.address)!,
                website : (this.myForm.value.website)!
             }
             this.serviceDb.editContact(i,newobj)
           }
           
          }  
      }else{
        console.log(newob)
        this.serviceDb.insertContact(newob)
      }
    this.router.navigate(['']);
  }

}
