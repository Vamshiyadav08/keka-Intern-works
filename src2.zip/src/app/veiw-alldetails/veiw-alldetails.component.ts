import { Component } from '@angular/core';
import { UserdetailsService } from '../shared/userdetails.service';
import { ActivatedRoute, Router } from '@angular/router';
import { user } from '../shared/user';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-veiw-alldetails',
  templateUrl: './veiw-alldetails.component.html',
  styleUrls: ['./veiw-alldetails.component.css'],
})
export class VeiwAlldetailsComponent{
  id: string = '';
  nameEle!: string;
  email!: string;
  mobile!: string;
  landline!: string;
  website!: string;
  address!: string;

  currUser!: user;
  constructor(
    private usd: UserdetailsService,
    private router: ActivatedRoute,
    private route: Router
  ) {}

  ngOnInit(): void {
    this.router.paramMap.subscribe((params) => {
      let userid = +params.get('id')!;
      for (let i in this.usd.userArray) {
        if (this.usd.userArray[i].id == userid) {
          console.log(this.usd.userArray[i]);
          this.currUser = this.usd.userArray[i];
        }
      }
      console.log(this.currUser.id + 'USer Id');
    });
  }

  deletee(id: number) {
    for (let i = 0; i < this.usd.userArray.length; i++) {
      if (this.usd.userArray[i].id == id) {
        this.usd.userArray.splice(i, 1);
        this.route.navigate(['']);
      }
    }
  }

  edit(obj_id: number) {
    this.route.navigate(['/edit'], {
      queryParams: { display: true, id: obj_id },
    });
  }
}
