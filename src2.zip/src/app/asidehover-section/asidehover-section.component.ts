import { Component } from '@angular/core';
import { UserdetailsService } from '../shared/userdetails.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-asidehover-section',
  templateUrl: './asidehover-section.component.html',
  styleUrls: ['./asidehover-section.component.css']
})
export class AsidehoverSectionComponent {
  constructor(public serviceDb:UserdetailsService ,private router:Router){

  }


 
}
