import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup, Validators} from '@angular/forms';
import { user } from '../shared/userModel';
import {  Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ContactService } from '../shared/contact.service';
import {v4 as uuid} from 'uuid'


@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
  contactUser: user={
    id : '',
    name:"",
    email : '',
    mobile : '',
    landline : '',
    address : '',
    website :'',

  }

  constructor(private contactService :ContactService,
              private activatedRoute:ActivatedRoute,
              private route:Router 
  ){}
  contactId:string="Add"
  autoFillForm(user : user){
    
        this.myForm.patchValue({
          name: user.name,
          email: user.email,
          mobile: user.mobile,
          landline: user.landline,
          website: user.website,
          address: user.address,
        })
    
  }
 
  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params)=>{
      this.contactId=params['id']
      this.contactService
      .editContact(this.contactId)
      .subscribe((data)=>
      {
        this.autoFillForm(data)  
      })
    })  
  }
  
  myForm = new FormGroup(
    {
      name : new FormControl('',[Validators.required]),
      email : new FormControl('',[Validators.required,Validators.email]),
      mobile: new FormControl('', [Validators.required]),
      landline : new FormControl(''),
      website : new FormControl(''),
      address : new FormControl('')
    }
  )
;
 onSubmit(){
   this.myForm.markAllAsTouched();
   if(this.myForm.valid){
    let contactObj = new user(
      '',
      this.myForm.value.name!,
      this.myForm.value.email!,
      this.myForm.value.mobile!,
      this.myForm.value.landline!,
      this.myForm.value.website!,
      this.myForm.value.address!
    )
    if(this.contactId!="Add"){
      console.log("edit"+this.contactId)
     
          let newContactObj = new user(
            this.contactId,
            this.myForm.value.name!,
            this.myForm.value.email!,
            this.myForm.value.mobile!,
            this.myForm.value.landline!,
            this.myForm.value.address!,
            this.myForm.value.website!,
          )
          this.contactService.edit(newContactObj).subscribe();
          // this.route.navigate([`contacts/contactDetails/${this.contactService.contactArray[i].id}`]);
          
        
     }
    else{ 
      this.contactService.postContact(contactObj).subscribe(  );
       this.route.navigate([`contacts/contactDetails/${contactObj.id}`])
     } 
   }
    
  }
  formSubmitBtn:string='add';
}
