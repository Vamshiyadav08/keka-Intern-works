import { identifierName } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ContactService } from '../shared/contact.service';
import { user } from '../shared/userModel';

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.css'],
})
export class ContactDetailsComponent implements OnInit {
  contactUser: user = {
    name: '',
    email: '',
    id: '',
    website: '',
    address: '',
    landline: '',
    mobile: '',
  };

  contactId!: string;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private contactService: ContactService
  ) {}

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params) => {
      this.contactId = params['id'];
      this.contactService
        .getContactProfile(this.contactId)
        .subscribe((data) => (this.contactUser = data));
    });
  }

  delete(id: string) {
    this.contactService.deleteContact(this.contactId).subscribe(() => {
      this.contactService
        .getContacts()
        .subscribe((data) => this.contactService.updateSubject(data));
    });
    this.router.navigate(['contacts'])
  }

  edit(id: string) {
    this.router.navigate([`contacts/edit/${id}`]);
  }
}
