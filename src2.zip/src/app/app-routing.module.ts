import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { ContactListComponent } from './contact-list/contact-list.component';


const routes: Routes = [
  {
    path:'contacts', component:ContactListComponent,
    children:
    [
      {path:'contactDetails/:id',component:ContactDetailsComponent},
      {path:'add',component:ContactFormComponent},
      {path:'edit/:id',component:ContactFormComponent}
    ]
  },
  { path: '',   redirectTo: '/contacts', pathMatch: 'full' },
 
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
