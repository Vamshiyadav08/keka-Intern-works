"use strict";
var _a;
class userDetails {
    constructor(_id, nameEle, email, mobile, landline, website, address) {
        this._id = _id;
        this.nameEle = nameEle;
        this.email = email;
        this.mobile = mobile;
        this.landline = landline;
        this.website = website;
        this.address = address;
    }
}
let count = Math.random();
let nameEle = document.getElementById("name");
let email = document.getElementById("email");
let mobile = document.getElementById("mobile");
let landline = document.getElementById("landline");
let website = document.getElementById("website");
let address = document.getElementById("address");
let formBtn = document.getElementById("formBtn");
let asideContainer = document.getElementById("asideContainer");
let editBtn = document.getElementById("editBtn");
let deleteBtn = document.getElementById("deleteBtn");
let addForm = document.getElementById("showForm");
let asideSection = document.getElementsByClassName("aside-section");
let requiredFeild = document.getElementById("requiredFeild");
let allDetailsContainer = document.getElementById("veiwdetails");
let form = document.getElementById("form");
function setItemInLocalStorage(item) {
    localStorage.setItem("ele", JSON.stringify(item));
}
function getItemfromLocalStorage() {
    let item = JSON.parse(localStorage.getItem("ele"));
    return item;
}
asidehoverSection();
function formValidation(checkfeild, errorfeild, content) {
    if (checkfeild.value == "") {
        errorfeild.textContent = `*${content} is required`;
        requiredFeild.textContent = "*Please fill the required feilds";
    }
    else {
        errorfeild.textContent = "";
    }
}
function displayForm(value, obj) {
    formBtn.textContent = value == "addForm" ? "Add" : "save Changes";
    let nameError = document.getElementById("nameError");
    let emailError = document.getElementById("eamilError");
    let mobileError = document.getElementById("mobileError");
    nameEle.value = obj.nameEle;
    mobile.value = obj.mobile;
    email.value = obj.email;
    landline.value = obj.landline;
    website.value = obj.website;
    address.value = obj.address;
    form.onsubmit = function (event) {
        event === null || event === void 0 ? void 0 : event.preventDefault();
        if (nameEle.value != "" && email.value != "" && mobile.value != "") {
            requiredFeild.textContent = "";
            nameError.textContent = "";
            emailError.textContent = "";
            mobileError.textContent = "";
            if (value == "addForm") {
                let objDetails = new userDetails(count, nameEle.value, email.value, mobile.value, landline.value, website.value, address.value);
                count += 1;
                let item = getItemfromLocalStorage();
                item.push(objDetails);
                setItemInLocalStorage(item);
                asidehoverSection();
            }
            else {
                let objDatabase = getItemfromLocalStorage();
                for (let i in objDatabase) {
                    if (objDatabase[i]._id == obj._id) {
                        objDatabase[i] = { _id: obj._id, nameEle: nameEle.value, mobile: mobile.value, email: email.value, landline: landline.value, website: website.value, address: address.value, };
                    }
                }
                setItemInLocalStorage(objDatabase);
                asidehoverSection();
            }
        }
        else {
            formValidation(nameEle, nameError, "name");
            formValidation(email, emailError, "emil");
            formValidation(mobile, mobileError, "mobile");
        }
    };
}
(_a = document.getElementById("Home")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", () => {
    asidehoverSection();
});
addForm.addEventListener("click", () => {
    form.classList.remove("hide-form");
    allDetailsContainer.classList.add("hide-details");
    displayForm("addForm", { _id: 0, nameEle: "", email: "", mobile: "", landline: "", website: "", address: "", });
});
function asidehoverSection() {
    form.classList.add("hide-form");
    asideContainer.innerHTML = "";
    let objDatabase = getItemfromLocalStorage();
    for (let i in objDatabase) {
        let asideitem = `<div>
                    <p class="aside-header">${objDatabase[i].nameEle}</p>
                    <p class="aside-item">${objDatabase[i].email}</p>
                    <p class="aside-item">${objDatabase[i].mobile}</p> </div>`;
        let addlistSection = document.createElement("div");
        addlistSection.setAttribute("id", `${objDatabase[i]._id}`);
        addlistSection.setAttribute("class", "aside-section");
        addlistSection.innerHTML = asideitem;
        addlistSection.onclick = function () {
            veiwallUserDetails(objDatabase[i]);
            asidehoverbgChange(objDatabase[i]);
        };
        asideContainer.appendChild(addlistSection);
    }
    asideBorderstyle(objDatabase.length);
}
function asidehoverbgChange(obj) {
    Array.from(asideSection).forEach((ele) => {
        ele.style.backgroundColor = "white";
    });
    let hoverdItem = document.getElementById(`${obj._id}`);
    hoverdItem.style.backgroundColor = "#cee7f2";
}
function asideBorderstyle(dbLength) {
    Array.from(asideSection).forEach((ele, index) => {
        if (index + 1 == dbLength) {
            ele.style.borderBottom = "1px solid #ccc";
        }
    });
}
function veiwallUserDetails(obj) {
    form.classList.add("hide-form");
    allDetailsContainer.classList.remove("hide-details");
    document.getElementById("menuName").textContent = obj.nameEle;
    document.getElementById("menuEmail").textContent = obj.email;
    document.getElementById("menuMobile").textContent = obj.mobile;
    document.getElementById("menuLandline").textContent = obj.landline;
    document.getElementById("menuwebsite").textContent = obj.website;
    document.getElementById("menuAdress").textContent = obj.address;
    editBtn.onclick = function () {
        form.classList.remove("hide-form");
        allDetailsContainer.classList.add("hide-details");
        displayForm("editormbtn", obj);
    };
    deleteBtn.onclick = function () {
        deleteForm(obj);
    };
}
function deleteForm(obj) {
    let objDatabase = getItemfromLocalStorage();
    var indexNumber;
    objDatabase.forEach((ele, index) => {
        if (ele._id == obj._id) {
            indexNumber = index;
        }
    });
    objDatabase.splice(indexNumber || 0, 1);
    setItemInLocalStorage(objDatabase);
    asidehoverSection();
    allDetailsContainer.classList.add("hide-details");
}
