class userDetails {
  _id: number;
  nameEle: string;
  email: string;
  mobile: string;
  landline: string;
  website: string;
  address: string;
  constructor(_id: number,nameEle: string,email: string,mobile: string,landline: string,website: string,address: string) 
  {
    this._id = _id;
    this.nameEle = nameEle;
    this.email = email;
    this.mobile = mobile;
    this.landline = landline;
    this.website = website;
    this.address = address;
  }
}
let count 
= Math.random();
let nameEle = document.getElementById("name") as HTMLInputElement;
let email = document.getElementById("email") as HTMLInputElement;
let mobile = document.getElementById("mobile") as HTMLInputElement;
let landline = document.getElementById("landline") as HTMLInputElement;
let website = document.getElementById("website") as HTMLInputElement;
let address = document.getElementById("address") as HTMLInputElement;
let formBtn = document.getElementById("formBtn") as HTMLButtonElement;
let asideContainer = document.getElementById("asideContainer") as HTMLElement;
let editBtn = document.getElementById("editBtn") as HTMLElement;
let deleteBtn = document.getElementById("deleteBtn") as HTMLElement;
let addForm = document.getElementById("showForm") as HTMLElement;
let asideSection = document.getElementsByClassName("aside-section");
let requiredFeild = document.getElementById("requiredFeild") as HTMLInputElement;
let allDetailsContainer = document.getElementById("veiwdetails") as HTMLElement;

let form = document.getElementById("form") as HTMLFormElement;
function setItemInLocalStorage(item: Array<object>) {
  localStorage.setItem("ele", JSON.stringify(item));
}
function getItemfromLocalStorage() {
  let item = JSON.parse(localStorage.getItem("ele") as string) as Array<object>;
  return item;
}
asidehoverSection();
function formValidation(
  checkfeild: HTMLInputElement,
  errorfeild: HTMLElement,
  content: string
) {
  if (checkfeild.value == "") {
    errorfeild.textContent = `*${content} is required`;
    requiredFeild.textContent = "*Please fill the required feilds";
  } else {
    errorfeild.textContent = "";
  }
}
function displayForm(value: string, obj: userDetails) {
  formBtn.textContent = value == "addForm" ? "Add" : "save Changes";
  let nameError = document.getElementById("nameError") as HTMLElement;
  let emailError = document.getElementById("eamilError") as HTMLElement;
  let mobileError = document.getElementById("mobileError") as HTMLElement;
  nameEle.value = obj.nameEle;
  mobile.value = obj.mobile;
  email.value = obj.email;
  landline.value = obj.landline;
  website.value = obj.website;
  address.value = obj.address;

  form.onsubmit = function (event) {
    event?.preventDefault();
    if (nameEle.value != "" && email.value != "" && mobile.value != "") {
      requiredFeild.textContent = "";
      nameError.textContent = "";
      emailError.textContent = "";
      mobileError.textContent = "";
      if (value == "addForm") {
        let objDetails = new userDetails(count,nameEle.value,email.value,mobile.value,landline.value,website.value,address.value);
        count += 1;
        let item = getItemfromLocalStorage();
        item.push(objDetails);
        setItemInLocalStorage(item);
        asidehoverSection();
      } else {
        let objDatabase = getItemfromLocalStorage();
        for (let i in objDatabase) {
          if ((objDatabase[i] as userDetails)._id == obj._id) {
            objDatabase[i] = {_id: obj._id, nameEle: nameEle.value, mobile: mobile.value, email: email.value, landline: landline.value, website: website.value,address: address.value,};
          }
        }
        setItemInLocalStorage(objDatabase);
        asidehoverSection();
      }
    } else {
      formValidation(nameEle, nameError, "name");
      formValidation(email, emailError, "emil");
      formValidation(mobile, mobileError, "mobile");
    }
  };
}
document.getElementById("Home")?.addEventListener("click", () => {
  asidehoverSection();
});

addForm.addEventListener("click", () => {
  form.classList.remove("hide-form");
  allDetailsContainer.classList.add("hide-details");
  displayForm("addForm", {_id: 0,nameEle: "",email: "",mobile: "",landline: "",website: "",address: "",});
});

function asidehoverSection() {
  form.classList.add("hide-form");
  asideContainer.innerHTML = "";
  let objDatabase = getItemfromLocalStorage();
  for (let i in objDatabase) {
    let asideitem = `<div>
                    <p class="aside-header">${(objDatabase[i] as userDetails).nameEle }</p>
                    <p class="aside-item">${(objDatabase[i] as userDetails).email}</p>
                    <p class="aside-item">${(objDatabase[i] as userDetails).mobile}</p> </div>`;
    let addlistSection = document.createElement("div");
    addlistSection.setAttribute("id", `${(objDatabase[i] as userDetails)._id}`);
    addlistSection.setAttribute("class", "aside-section");
    addlistSection.innerHTML = asideitem;
    addlistSection.onclick = function () {
      veiwallUserDetails(objDatabase[i] as userDetails);
      asidehoverbgChange(objDatabase[i] as userDetails);
    };
    asideContainer.appendChild(addlistSection);
  }
  asideBorderstyle(objDatabase.length);
}

function asidehoverbgChange(obj: userDetails) {
  Array.from(asideSection).forEach((ele) => {
    (<HTMLElement>ele).style.backgroundColor = "white";
  });
  let hoverdItem = document.getElementById(`${obj._id}`) as HTMLElement;
  hoverdItem.style.backgroundColor = "#cee7f2";
}

function asideBorderstyle(dbLength: number) {
  Array.from(asideSection).forEach((ele, index) => {
    if (index + 1 == dbLength) {
      (<HTMLElement>ele).style.borderBottom = "1px solid #ccc";
    }
  });
}

function veiwallUserDetails(obj: userDetails) {
  form.classList.add("hide-form");
  allDetailsContainer.classList.remove("hide-details");
  (<HTMLElement>document.getElementById("menuName")).textContent = obj.nameEle;
  (<HTMLElement>document.getElementById("menuEmail")).textContent = obj.email;
  (<HTMLElement>document.getElementById("menuMobile")).textContent = obj.mobile;
  (<HTMLElement>document.getElementById("menuLandline")).textContent =obj.landline;
  (<HTMLElement>document.getElementById("menuwebsite")).textContent =obj.website;
  (<HTMLElement>document.getElementById("menuAdress")).textContent =obj.address;
  editBtn.onclick = function () {
    form.classList.remove("hide-form");
    allDetailsContainer.classList.add("hide-details");
    displayForm("editormbtn", obj);
  };
  deleteBtn.onclick = function () {
    deleteForm(obj);
  };
}

function deleteForm(obj: userDetails) {
  let objDatabase = getItemfromLocalStorage();
  var indexNumber;
  objDatabase.forEach((ele, index) => {
    if ((ele as userDetails)._id == obj._id) {
      indexNumber = index;
    }
  });
  objDatabase.splice(indexNumber || 0, 1);
  setItemInLocalStorage(objDatabase);
  asidehoverSection();
  allDetailsContainer.classList.add("hide-details");
}
